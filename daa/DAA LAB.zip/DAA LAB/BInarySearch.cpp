#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cout << "Enter the size of array" << endl;

    cin >> n;

    int arr[n];
    int temp[n];
    cout << "Input array" << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
        temp[i]=arr[i];
    }
    cout << "Find the element to be found" << endl;
    int x;
    cin >> x;
    sort(arr, arr + n);

    int low = 0;
    int high = n - 1;
    while (low < high)
    {
        int mid = (low + high) / 2;
        if (arr[mid] == x)
        {
            cout << "Element found at index ";
            for (int i = 0; i < n; i++)
            {
                if (x == temp[i])
                    cout << i << endl;
            }
            return 0;
        }
        else if (arr[mid] > x)
        {
            high = mid;
        }
        else
        {
            low = mid;
        }
    }

    cout << "Element not found" << endl;
    return 0;
}