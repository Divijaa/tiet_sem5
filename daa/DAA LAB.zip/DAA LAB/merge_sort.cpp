#include<iostream>
#include<bits/stdc++.h>
using namespace std;

void merge(int arr[],int p,int q,int r);
void merge_sort(int arr[],int p,int r){
    if(p<r){
        int q=(p+r)/2;
        merge_sort(arr,p,q);
        merge_sort(arr,q+1,r);
        merge(arr,p,q,r);
    }
    else{
        return;
    }
}

void merge(int arr[],int p,int q,int r){
    int i=p;
    int j=q+1;
    int k=p;

    int temp[r+1];


    while(i<=q && j<=r){
        if(arr[i] < arr[j]){
            temp[k]=arr[i];
            i++;
        }
        else{
            temp[k]=arr[j];
            j++;   
        }
        k++;
    }
    while(i<=q){
        temp[k]=arr[i];
        i++;
        k++;
    }
    while(j<=r){
        temp[k]=arr[j];
        j++;
        k++;
    }
    for(int a=p;a<=r;a++){
        arr[a]=temp[a];
    }
}

void print_arr(int arr[],int x){
    for(int i=0;i<x;i++){
        cout<<arr[i]<<endl;
    }
}
int main(){
    int arr[]={38,27,43,3,9,82,10};
    int size = sizeof(arr) / sizeof(arr[0]);
    merge_sort(arr,0,size-1);

    print_arr(arr,size);
    return 0;
}