#include<bits/stdc++.h>
using namespace std;
int partition(int arr[],int p,int r){
    int pvt=arr[r];
    int indx=p;
    for(int i=p;i<r;i++){
        if(arr[i]<=pvt){
            swap(arr[i],arr[indx]);
            indx++;
        }
    }
    swap(arr[indx],arr[r]);
    return indx;
}
void quick_sort(int arr[],int p,int r){
    if(p<r){
        int q=partition(arr,p,r);
        quick_sort(arr,p,q-1);
        quick_sort(arr,q+1,r);
    }
    else{
        return;
    }

}
int main(){
    int arr[]={5,4,3,2,1};
    int sz=sizeof(arr)/sizeof(arr[0]);
    quick_sort(arr,0,sz-1);
    //partition(arr,0,sz-1);
    for(int i=0;i<sz;i++){
        cout<<arr[i]<<endl;
    }
    return 0;
}