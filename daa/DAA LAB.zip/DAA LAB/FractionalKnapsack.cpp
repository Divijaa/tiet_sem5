#include<bits/stdc++.h>
using namespace std;

class item{
    public:
    int id,profit,wt;
    float p_W,x;
};

bool comparison(item a , item b){
    return (a.p_W>b.p_W);
}

int main(){
    cout<<"Enter number of items"<<endl;
    int n;
    cin>>n;
    cout<<"Enter value of Knapsack"<<endl;
    int k;
    cin>>k;


    item items[n];

    for(int i=0;i<n;i++){
        items[i].id=i+1;
        cout<<"Enter the profit and weight for "<<i+1<<" item"<<endl;
        cin>>items[i].profit;
        cin>>items[i].wt;
        items[i].p_W=items[i].profit/items[i].wt;
    }

    sort(items,items+n,comparison);
    int i=0,pf=0;
    while(k>0){
        items[i].x=min(items[i].wt,k);
        k=k-items[i].x;

        items[i].x=items[i].x/items[i].wt;
        pf+=items[i].profit*items[i].x;  
        i++;     
    }
    cout<<pf<<endl;


}