#include<bits/stdc++.h>
using namespace std;


int CoinExhange(int coins[],int n,int amt){
    int dp[n+1][amt+1];

    for(int i=0;i<=n;i++){
        for(int j=0;j<=amt;j++){
            if(j==0) dp[i][j]=0;
            else if(i==0) dp[i][j]=1e5;
            else if (coins[i-1]>j) dp[i][j]=dp[i-1][j];
            else dp[i][j]=min(dp[i-1][j],1+dp[i][j-coins[i-1]]);
        }
    }

    return dp[n][amt]>1e4 ? -1 : dp[n][amt];

}
int main(){
    int coins[3]={1,2,5};
    int amt=6;

    cout<<"Minimum number of coins needed to make the given amount is "<<CoinExhange(coins,3,amt)<<endl;

}