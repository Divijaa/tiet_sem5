#include<iostream>
#include<string>
#include<vector>
#include<climits>
using namespace std;

int matrixChainOrder(vector<int> p , int n){
    // defining a vector of n elements with each element being a vector of n elements all being 0
    vector<vector<int>> m(n , vector<int> (n,0));
    int i,j,k,L,q;
    for(i=1 ; i<n ; i++){
        m[i][i] = 0;
    }
    for(L=2 ; L<n ; L++){
        for(i=1 ; i<n-L+1 ; i++){
            j = i+L-1;
            m[i][j] = INT_MAX;
            for(k=i ; k<=j-1 ; k++){
                q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];
                if(q<m[i][j])
                    m[i][j] = q;
            }
        }
    }
    return m[1][n - 1];
}

int main() {
    vector<int> a = {7,1,5,4,2}; // answer is 42
    int size = a.size();
    cout<<"Minimum number of multiplications = "<<matrixChainOrder(a,size);
    return 0;
}