#include<bits/stdc++.h>
using namespace std;
vector<int> msi(vector<int> a,vector<int> b)
{
    vector<int> c;
    int n=a.size()-1;
    int m=b.size()-1;
    int i=0;
    int j=0;
    while(i<=n && j<=m)
    {
        if(a[i]==b[j])
        {
            c.push_back(a[i]);
            i++;
            j++;
        }
        else if(a[i]<b[j])
        {

            c.push_back(a[i]);
            i++;
        }
        else if(a[i]>b[j])
        {
            c.push_back(b[j]);
            j++;
        }
    }
    while(i<=n)
    {
        c.push_back(a[i]);
        i++;
    }
    while(j<=m)
    {
        c.push_back(b[j]);
        j++;
    }
    return c;
}
void merge(vector<int> &v,int s,int e)
{
    int m=(s+e)/2;
    vector<int> temp;
    int i=s;
    int j=m+1;
    while(i<=m && j<=e)
    {
        if(v[i]<=v[j])
        {
            temp.push_back(v[i]);
            i++;
        }
        else
        {
            temp.push_back(v[j]);
            j++;
        }
    }
    while(i<=m)
    {
        temp.push_back(v[i]);
        i++;

    }
    while(j<=e)
    {
        temp.push_back(v[j]);
        j++;
    }
    for(int i=s;i<=e;i++)
    {
        v[i]=temp[i-s];
    }

}
vector<int> msr(vector<int> &a,int s,int e)
{
    vector<int> c;
    if(s<e)
    {
        int m=(s+e)/2;
        msr(a,s,m);
        msr(a,m+1,e);
        merge(a,s,e);
    }
    return c;
}
int main()
{
    vector<int> a={1,3,5,7,9};
    vector<int> b={2,4,6,8};
    vector<int> c={3,5,7,3,1,9,0,3};
    cout<<"merge sort iterative: ";
    vector<int> ans=msi(a,b);
    for(int i=0;i<ans.size();i++)
    {
        cout<<ans[i]<<" ";
    }
    cout<<endl;
    cout<<"merge sort recursive: ";
    msr(c,0,c.size()-1);
    for(int i=0;i<c.size();i++)
    {
        cout<<c[i]<<" ";
    }
    return 0;
}