#include<bits/stdc++.h>
using namespace std;
int bsi(vector<int> a,int k)
{
    int n=a.size();
    int s=0;
    int e=a.size();
    while(s<=e)
    {
        int m=(s+e)/2;
        if(a[m]==k)
        {
            return m;
        }
        else if(a[m]>k)
        {
            e=m-1;
        }
        else if(a[m]<k)
        {
            s=m+1;
        }
    }
    return -1;
}
int bsr(vector<int> a,int s,int e,int k)
{
    int m=(s+e)/2;
    if(a[m]==k) return m;
    if(a[m]>k)
    {
        return bsr(a,s,m-1,k);
    }
    else if(a[m]<k)
    {
        return bsr(a,m+1,e,k);
    }
    return -1;
}
int main()
{
    vector<int> a={3,5,6,7,9,10,13,15,26};
    int k=10;
    cout<<"binary seach iterative: "<<bsi(a,k)<<endl;
    cout<<"binary seach recursive: "<<bsr(a,0,a.size(),k);

}