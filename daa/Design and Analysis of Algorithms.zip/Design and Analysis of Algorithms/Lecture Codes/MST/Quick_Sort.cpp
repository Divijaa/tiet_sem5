#include<bits/stdc++.h>
using namespace std;
void qsi(vector<int> &a)
{

}
int par(vector<int> a,int s,int e)
{
    int pi=a[s];
    int c=0;
    for(int i=s+1;i<=e;i++)
    {
        if(a[i]<=pi) c++;
    }
    int p=s+c;
    swap(a[p],a[s]);
    int i=s;
    int j=e;
    while(i<p && j>p)
    {
        while(a[i]<=p)
        {
            i++;
        }
        while(a[j]>p)
        {
            j--;
        }
        if(i<p && j>p)
        {
            swap(a[i],a[j]);
            i++;
            j--;
        }
    }
    return p;
    

}
void qsr(vector<int> &a,int s,int e)
{
    if(s>=e) return;
    int p=par(a,s,e);
    qsr(a,s,p-1);
    qsr(a,p+1,e);
}
int main()
{
    vector<int> a={4,7,5,2,9,0,1};
    cout<<"quick sort recursive: ";
    qsr(a,0,a.size()-1);
    for(int i=0;i<a.size();i++)
    {
        cout<<a[i]<<" ";
    }
    return 0;
}