#include<bits/stdc++.h>
using namespace std;
double knapsack(vector<double> profit, vector<double> weight, int maxweight)
{
    vector<pair<double,int>> pw;
    for(int i=0;i<profit.size();i++)
    {
        pw.push_back(make_pair((profit[i]/weight[i]),i));
    }
    sort(pw.begin(),pw.end());
    reverse(pw.begin(),pw.end());
    int i=0;
    double ans;
    while(maxweight!=0)
    {
        if(maxweight!=0 && maxweight<weight[pw[i].second])
        {
            int left=maxweight;
            maxweight=0;
            ans=ans+(profit[pw[i].second]*(left/weight[pw[i].second]));
            continue;
        }
        maxweight=maxweight-weight[pw[i].second];
        ans=ans+profit[pw[i].second];
        i++;
    }
    return ans;
}
int main()
{
    vector<double> profit={10,5,15,7,6,18,3};
    vector<double> weight={2,3,5,7,1,4,1};
    int maxweight=15;
    double k=knapsack(profit,weight,maxweight);
    cout<<k;
    return 0;
}