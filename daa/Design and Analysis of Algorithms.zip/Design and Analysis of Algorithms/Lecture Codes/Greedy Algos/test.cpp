#include<bits/stdc++.h>
using namespace std;
vector<string> jobsequencing(vector<string> job, vector<int> profit, vector<int> deadlines)
{
	int max=0;
    for(int i=0;i<n;i++)
	{
		if(max<job[i][1]) max=jab[i][1];
	}
    vector<string> s(max,"0");
    for(int i=0;i<n;i++)
    {
        int temp=job[i][1];
        int placed=1;
        temp--;
        while(temp!=-1)
        {
            if(s[temp]=="0")
            {
                s[temp]=job[i][0];
                break;
            }
            else temp--;
        }
    }
    return s;
}
int main()
{
    vector<string> job={"j1","j2","j3","j4","j5"};
    vector<int> profit={20,15,10,5,1};
    vector<int> deadlines={2,2,1,3,3};
    vector<string> s=jobsequencing(job,profit,deadlines);
    for(int i=0;i<s.size();i++)
    {
        cout<<s[i]<<endl;
    }
    return 0;
}