#include<bits/stdc++.h>
using namespace std;
vector<string> jobsequencing(vector<string> job, vector<int> profit, vector<int> deadlines)
{
    int num=*max_element(deadlines.begin(),deadlines.end());
    vector<string> s(num,"0");
    for(int i=0;i<profit.size();i++)
    {
        int temp=deadlines[i];
        int placed=1;
        temp--;
        while(temp!=-1)
        {
            if(s[temp]=="0")
            {
                s[temp]=job[i];
                break;
            }
            else temp--;
        }
    }
    return s;
}
int main()
{
    vector<string> job={"j1","j2","j3","j4","j5"};
    vector<int> profit={20,15,10,5,1};
    vector<int> deadlines={2,2,1,3,3};
    vector<string> s=jobsequencing(job,profit,deadlines);
    for(int i=0;i<s.size();i++)
    {
        cout<<s[i]<<endl;
    }
    return 0;
}