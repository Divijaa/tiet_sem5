#include<iostream>
using namespace std;
int binary_search_r(int arr[],int a,int n,int key)
{
    if(n>=1)
    {
        int mid=a+(n-a)/2;
        if(arr[mid]==key)
        {
            return mid;
        }
        else if(arr[mid]>key)
        {
            return binary_search_r(arr,a,mid-1,key);
        }
        else
        {
            return binary_search_r(arr,mid+1,n,key);
        }
    }
    return -1;
}
int binary_search_i(int arr[],int s, int e,int key)
{
    while(s<=e)
    {
        int mid=s+(e-s)/2;
        if(arr[mid]==key)
        {
            return mid;
        }
        else if(arr[mid]<key)
        {
            s=mid+1;
        }
        else
        {
            e=mid-1;
        }
    }
    return -1;
}
int main()
{
    int arr[]={3,4,6,8,9};
    int n=sizeof(arr)/sizeof(int);
    int key=8;
    int flag=binary_search_i(arr,0,n-1,key);
    if(flag==-1)
    {
        cout<<key<<" not found"<<endl;
    }
    else
    {
        cout<<key<<" is found at index "<<flag<<endl;
    }
    return 0;
}