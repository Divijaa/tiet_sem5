#include<iostream>
#include<vector>
using namespace std;
void merge_help(vector<int> &arr,int s,int e)
{
    vector<int> temp;
    int i=s;
    int mid=(s+e)/2;
    int j=mid+1;
    
}
void mergesort_r(vector<int> &arr,int s,int e)
{
    if(s>=e)
    {
        return;
    }
    int mid=(s+e)/2;
    mergesort_r(arr,s,mid);
    mergesort_r(arr,mid+1,e);
    return merge_help(arr,s,e);
}
int main()
{
    vector<int> arr={10,5,2,9,5,3,6};
    int s=0;
    int e=arr.size()-1;
    mergesort_r(arr,s,e);
    for(int i=0;i<arr.size();i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}