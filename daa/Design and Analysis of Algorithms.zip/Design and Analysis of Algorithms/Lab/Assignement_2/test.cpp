#include <bits/stdc++.h>
using namespace std;
void print(vector<vector<int>> v)
{
    for(int i=0;i<v.size();i++)
    {
        for(int j=0;j<v[i].size();j++)
        {
            cout<<v[i][j]<<" ";
        }
        cout<<endl;
    }
}
int main() {
	// your code goes here
	int t;
	cin>>t;
	while(t--)
	{
	    int n,k;
	    cin>>n>>k;
	    vector<vector<int>> v(k,vector<int> (3,0));
	    int count=0;
	    for(int i=0;i<n;i++)
	    {
	        int s,e,c;
	        cin>>s>>e>>c;
	        int d=e-s;
	        if(v[c-1][2]==0)
	        {
	            v[c-1][0]=s;
	            v[c-1][1]=e;
	            v[c-1][2]=d;
                count++;
	        }
            else
            {
                if(s>=v[c-1][1])
                {
                    v[c-1][0]=s;
	                v[c-1][1]=e;
	                v[c-1][2]=d;
                    count++;
                }
                else if(d<v[c-1][2])
                {
                    v[c-1][0]=s;
	                v[c-1][1]=e;
	                v[c-1][2]=d;
                }
            }
	    }
	    cout<<count<<endl;
	}
	return 0;
}
