#include<bits/stdc++.h>
using namespace std;
int s;

boll sumofsubset(vector<int> a,int n,int sum)
{
    if(sum==0) return true;
    if(n==0) return false;
    if(a[n-1]>sum)
    {
        
    }
}
int main()
{
    int m=35;
    vector<int> w={10, 7, 5, 18, 12, 20, 15};
    for(int i=0;i<w.size();i++)
    {
        s=w[i]*
    }

    return 0;
}